const Copyright = () => {
  return (
    <div className='text-center p-4 border-top'>
      <span>&copy;</span> 2024 Copyright:
      <a className='text-reset fw-bold' href='#'>
         RevTask.com
      </a>
    </div>
  );
};

export default Copyright;
