package com.teamD.RevTaskManagement.enums;

public enum ProjectStatus {
    ON_HOLD,
    IN_PROGRESS,
    COMPLETED
}
