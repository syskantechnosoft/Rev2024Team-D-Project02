package com.teamD.RevTaskManagement.enums;

public enum Role {
    ADMIN,
    MANAGER,
    ASSOCIATE
}