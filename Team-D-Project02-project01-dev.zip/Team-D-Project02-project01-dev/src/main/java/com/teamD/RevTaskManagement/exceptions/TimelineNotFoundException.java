package com.teamD.RevTaskManagement.exceptions;

public class TimelineNotFoundException extends RuntimeException {
    public TimelineNotFoundException(String message) {
        super(message);
    }
}
