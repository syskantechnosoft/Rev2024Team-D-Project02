package com.teamD.RevTaskManagement.enums;

public enum EmployeeStatus {
    ACTIVE,
    INACTIVE
}